import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Users, BriefcaseIcon, CheckCircle, Clock } from 'lucide-react';

const data = [
  { name: 'Jan', applications: 400, interviews: 240, hires: 100 },
  { name: 'Feb', applications: 300, interviews: 139, hires: 80 },
  { name: 'Mar', applications: 500, interviews: 280, hires: 120 },
  { name: 'Apr', applications: 780, interviews: 390, hires: 150 },
  { name: 'May', applications: 890, interviews: 480, hires: 200 },
  { name: 'Jun', applications: 690, interviews: 380, hires: 170 },
];

const stats = [
  { 
    icon: Users,
    title: 'Active Candidates',
    value: '1,234',
    change: '+12%',
    positive: true 
  },
  { 
    icon: BriefcaseIcon,
    title: 'Open Positions',
    value: '56',
    change: '+3',
    positive: true 
  },
  { 
    icon: CheckCircle,
    title: 'Successful Hires',
    value: '89',
    change: '+24%',
    positive: true 
  },
  { 
    icon: Clock,
    title: 'Time to Hire',
    value: '12 days',
    change: '-30%',
    positive: true 
  },
];

function StatCard({ icon: Icon, title, value, change, positive }: {
  icon: React.ElementType;
  title: string;
  value: string;
  change: string;
  positive: boolean;
}) {
  return (
    <motion.div 
      className="bg-white rounded-lg p-6 shadow-lg"
      whileHover={{ y: -5 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Icon className="h-6 w-6 text-blue-600" />
          </div>
          <h3 className="ml-3 text-lg font-medium text-gray-900">{title}</h3>
        </div>
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium ${
          positive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {change}
        </span>
      </div>
      <p className="mt-4 text-3xl font-semibold text-gray-900">{value}</p>
    </motion.div>
  );
}

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-100 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Recruitment Dashboard</h1>
          <p className="mt-2 text-gray-600">Track your recruitment metrics and performance</p>
        </div>

        <div className="grid grid-cols-1 gap-6 mb-8 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <StatCard key={index} {...stat} />
          ))}
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-xl font-semibold mb-6">Recruitment Pipeline Overview</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="applications" stroke="#3B82F6" strokeWidth={2} />
                <Line type="monotone" dataKey="interviews" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="hires" stroke="#6366F1" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
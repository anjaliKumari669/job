import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Brain, Users, ShieldCheck, Calendar, ArrowRight, CheckCircle, Menu, X, LineChart, UserCircle, LogOut } from 'lucide-react';
import { Dialog } from '@headlessui/react';
import { Toaster } from 'react-hot-toast';
import Dashboard from './components/Dashboard';
import Login from './components/Login';
import { supabase } from './lib/supabase';

function FeatureCard({ icon: Icon, title, description }: { icon: React.ElementType, title: string, description: string }) {
  return (
    <motion.div 
      className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
    >
      <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
        <Icon className="h-6 w-6 text-blue-600" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </motion.div>
  );
}

function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  return (
    <nav className="bg-white shadow-sm fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Brain className="h-8 w-8 text-blue-600" />
            <span className="ml-2 text-xl font-semibold">AI Recruiter</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-600 hover:text-gray-900">Home</Link>
            {user && (
              <Link to="/dashboard" className="text-gray-600 hover:text-gray-900">Dashboard</Link>
            )}
            {user ? (
              <button
                onClick={handleSignOut}
                className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 flex items-center gap-2"
              >
                <LogOut className="h-4 w-4" />
                Sign Out
              </button>
            ) : (
              <Link to="/login" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                Sign In
              </Link>
            )}
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setMobileMenuOpen(true)}>
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      <Dialog as="div" open={mobileMenuOpen} onClose={setMobileMenuOpen}>
        <Dialog.Panel className="fixed inset-0 z-50 bg-white p-4">
          <div className="flex items-center justify-between">
            <Brain className="h-8 w-8 text-blue-600" />
            <button onClick={() => setMobileMenuOpen(false)}>
              <X className="h-6 w-6" />
            </button>
          </div>
          <div className="mt-8 space-y-4">
            <Link to="/" className="block text-lg" onClick={() => setMobileMenuOpen(false)}>Home</Link>
            {user && (
              <Link to="/dashboard" className="block text-lg" onClick={() => setMobileMenuOpen(false)}>Dashboard</Link>
            )}
            {user ? (
              <button
                onClick={() => {
                  handleSignOut();
                  setMobileMenuOpen(false);
                }}
                className="block text-lg text-red-600"
              >
                Sign Out
              </button>
            ) : (
              <Link to="/login" className="block text-lg" onClick={() => setMobileMenuOpen(false)}>Sign In</Link>
            )}
          </div>
        </Dialog.Panel>
      </Dialog>
    </nav>
  );
}

function HomePage() {
  const features = [
    {
      icon: Brain,
      title: "Automated JD & CV Processing",
      description: "Advanced AI algorithms analyze job descriptions and resumes to extract key requirements and qualifications."
    },
    {
      icon: Users,
      title: "Intelligent Matching Engine",
      description: "Smart matching technology pairs candidates with positions based on skills, experience, and cultural fit."
    },
    {
      icon: ShieldCheck,
      title: "Bias-Aware Shortlisting",
      description: "Ethical AI ensures fair candidate evaluation while eliminating unconscious biases from the screening process."
    },
    {
      icon: Calendar,
      title: "Seamless Interview Scheduling",
      description: "Automated scheduling system coordinates interviews between hiring managers and candidates effortlessly."
    }
  ];

  const benefits = [
    {
      icon: LineChart,
      title: "Reduce time-to-hire by 60%",
      description: "Streamline your recruitment process significantly"
    },
    {
      icon: UserCircle,
      title: "Improve candidate quality by 40%",
      description: "Get better matched candidates for your roles"
    },
    {
      icon: ShieldCheck,
      title: "Eliminate hiring biases",
      description: "Ensure fair and objective candidate evaluation"
    },
    {
      icon: Calendar,
      title: "Scale recruitment efficiently",
      description: "Handle more positions without increasing team size"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 pt-16">
      {/* Hero Section */}
      <motion.div 
        className="relative overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <motion.h1 
              className="text-5xl font-bold text-gray-900 mb-6"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              Revolutionize Your Hiring Process with AI
            </motion.h1>
            <motion.p 
              className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              Transform your recruitment workflow with our intelligent screening platform that combines multi-agent AI systems with structured data intelligence.
            </motion.p>
            <motion.button 
              className="bg-blue-600 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Get Started <ArrowRight className="h-5 w-5" />
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <h2 className="text-3xl font-bold text-center mb-16">Our 4-Stage Intelligent Pipeline</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={index} {...feature} />
          ))}
        </div>
      </div>

      {/* Benefits Section */}
      <div className="bg-blue-600 text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">Why Choose Our Solution?</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div 
                key={index}
                className="bg-blue-700 rounded-lg p-6"
                whileHover={{ scale: 1.05 }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <benefit.icon className="h-12 w-12 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                <p className="text-blue-100">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Hiring Process?</h2>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Join leading companies that have revolutionized their recruitment with our AI-powered solution.
        </p>
        <motion.button 
          className="bg-blue-600 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Schedule a Demo <ArrowRight className="h-5 w-5" />
        </motion.button>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Toaster position="top-right" />
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;